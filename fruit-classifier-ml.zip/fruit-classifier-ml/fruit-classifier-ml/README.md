
# Fruit Classifier – Simple AI Project

This is a basic machine learning project that classifies fruits (Banana, Apple, Orange) based on their features like weight, size, and color.

## 📊 Dataset
- Manually created dataset with 3 fruit classes
- Features: Weight (g), Size (cm), Color (0–1 scale)

## 🧠 Model
- Algorithm: Random Forest
- Library: scikit-learn
- Evaluation: Confusion matrix & classification report

## 🔧 How to run
```bash
pip install -r requirements.txt
```
Then open `fruit_classifier.ipynb` in Jupyter Notebook or Google Colab.
